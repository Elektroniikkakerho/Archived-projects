//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Operation.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TOperationForm *OperationForm;
//---------------------------------------------------------------------------
__fastcall TOperationForm::TOperationForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TOperationForm::showOperation(AnsiString msg, AnsiString capt) {
    labelMessage->Caption=msg;
    Caption=capt;
    cancelled=false;
    ProgressBar1->Position = 0;
    OperationForm->Show();
}

void __fastcall TOperationForm::setProgressState(int perc) {
    if (perc > 100 || perc < 0) return;
    ProgressBar1->Position = perc;
}

void __fastcall TOperationForm::buttonCancelClick(TObject *Sender)
{
    cancelled=true;
}
//---------------------------------------------------------------------------
