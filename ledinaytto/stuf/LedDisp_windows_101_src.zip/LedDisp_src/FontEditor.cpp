//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "FontEditor.h"
#include "FontPalette.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TEditor *Editor;
//---------------------------------------------------------------------------
__fastcall TEditor::TEditor(TComponent* Owner)
    : TForm(Owner)
{
    int count=1;
    for(int y=0; y<7; y++) {
        for(int x=0; x<5; x++) {
            fontEditArray[x][y]=new TSpeedButton(Panel1);
            fontEditArray[x][y]->Parent=Panel1;
            fontEditArray[x][y]->OnClick=fontEditArrayChanged;
            fontEditArray[x][y]->AllowAllUp=true;
            fontEditArray[x][y]->GroupIndex=count;
            fontEditArray[x][y]->Flat=true;
            fontEditArray[x][y]->Width=16;
            fontEditArray[x][y]->Height=16;
            fontEditArray[x][y]->Left=x*16;
            fontEditArray[x][y]->Top=y*16;
            fontEditArray[x][y]->Glyph=PixelImage->Picture->Bitmap;
            fontEditArray[x][y]->NumGlyphs = 4;
            count++;
        }
    }
    UpDownCharCode->Max = CHARACTERS-1;
}
//---------------------------------------------------------------------------
void __fastcall TEditor::buttonPaletteClick(TObject *Sender)
{
    Fonts->Show();    
}
//---------------------------------------------------------------------------
void __fastcall TEditor::buttonClearClick(TObject *Sender)
{
    for(int y=0; y<7; y++) {
        for(int x=0; x<5; x++) {
            fontEditArray[x][y]->Down=false;
        }
    }
    fontEditArrayChanged(this);
}
//---------------------------------------------------------------------------

void __fastcall TEditor::EditCharCodeChange(TObject *Sender)
{
    int value=1;
    if (EditCharCode->Text.Length() > 0) {
        try {
            value=EditCharCode->Text.ToInt();
        } catch (EConvertError &error) {
            value=1;
            EditCharCode->Text=AnsiString("1");
        }
    }
    else EditCharCode->Text=AnsiString("1");

    if (value >= CHARACTERS) {
        value = CHARACTERS-1;
        EditCharCode->Text = AnsiString(value);
    }
    else if (value < 1) {
        value = 1;
        EditCharCode->Text=AnsiString("1");
    }

    EditCharASCII->Text=AnsiString((char)(value));

    bool font[5][7];
    Fonts->getFont5x7(value,font);
    for(int y=0; y<7; y++) {
        for(int x=0; x<5; x++) {
            fontEditArray[x][y]->Down = font[x][y];
        }
    }
    UpDownWidth->Position = Fonts->charWidth[value];

    Fonts->setCursor(value);
}
//---------------------------------------------------------------------------

void __fastcall TEditor::EditCharASCIIChange(TObject *Sender)
{
    unsigned char ch = 1;
    if (EditCharASCII->Text.Length() > 0) {
        ch = (unsigned char)(EditCharASCII->Text[1]);
    }

    UpDownCharCode->Position = (short)(ch);
}
//---------------------------------------------------------------------------

void __fastcall TEditor::EditCharWidthChange(TObject *Sender)
{
    int width = UpDownWidth->Position;
    if (EditCharWidth->Text.Length() == 0) {
        EditCharWidth->Text = AnsiString(width);
    }
    int show_width = width;
    if (show_width > 5) show_width = 5;

    Panel1->Width = show_width*16;
    Panel2->Width = show_width*16 + 9;

    Fonts->charWidth[UpDownCharCode->Position]=width;
    //Fonts->fontImages[UpDownCharCode->Position]->Width = 3*show_width;

    fontEditArrayChanged(this);
}
//---------------------------------------------------------------------------


void __fastcall TEditor::fontEditArrayChanged(TObject *Sender) {
    bool font[5][7];

    int width = UpDownWidth->Position;

    for(int y=0; y<7; y++) {
        for(int x=0; x<5; x++) {
            if (x<width) font[x][y]=fontEditArray[x][y]->Down;
            else font[x][y]=false;
        }
    }
    Fonts->setFont5x7(UpDownCharCode->Position,font);
}



void __fastcall TEditor::FormActivate(TObject *Sender)
{
    Fonts->setCursor(UpDownCharCode->Position);
}
//---------------------------------------------------------------------------


