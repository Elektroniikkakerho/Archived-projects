//---------------------------------------------------------------------
#include <vcl.h>
//include ShellExecuteA
#include <shellapi.h>

#pragma hdrstop

#include "About.h"
//--------------------------------------------------------------------- 
#pragma resource "*.dfm"
TAboutBox *AboutBox;
//--------------------------------------------------------------------- 
__fastcall TAboutBox::TAboutBox(TComponent* AOwner)
	: TForm(AOwner)
{
}
//---------------------------------------------------------------------
void __fastcall TAboutBox::OKButtonClick(TObject *Sender)
{
    Close();    
}
//---------------------------------------------------------------------------


void __fastcall TAboutBox::Label1Click(TObject *Sender)
{
    ShellExecute(NULL,"open","http://koti.mbnet.fi/zyc82/",
                 NULL, "", SW_SHOWNORMAL);
}
//---------------------------------------------------------------------------


void __fastcall TAboutBox::Label2Click(TObject *Sender)
{
    ShellExecute(NULL,"open",
                 "http://koti.mbnet.fi/zyc82/elektroniikka/LedDisp/",
                 NULL, "", SW_SHOWNORMAL);
}
//---------------------------------------------------------------------------


