//---------------------------------------------------------------------------

#ifndef OperationH
#define OperationH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TOperationForm : public TForm
{
__published:	// IDE-managed Components
    TButton *buttonCancel;
    TLabel *labelMessage;
    TProgressBar *ProgressBar1;
    void __fastcall buttonCancelClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TOperationForm(TComponent* Owner);

    void __fastcall showOperation(AnsiString msg, AnsiString capt);
    void __fastcall setProgressState(int perc);
    bool cancelled;
};
//---------------------------------------------------------------------------
extern PACKAGE TOperationForm *OperationForm;
//---------------------------------------------------------------------------
#endif
