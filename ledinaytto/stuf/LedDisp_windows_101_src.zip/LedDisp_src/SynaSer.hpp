// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'SynaSer.pas' rev: 6.00

#ifndef SynaSerHPP
#define SynaSerHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Synaser
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum THookSerialReason { HR_SerialClose, HR_Connect, HR_CanRead, HR_CanWrite, HR_ReadCount, HR_WriteCount };
#pragma option pop

typedef void __fastcall (__closure *THookSerialStatus)(System::TObject* Sender, THookSerialReason Reason, const AnsiString Value);

class DELPHICLASS ESynaSerError;
class PASCALIMPLEMENTATION ESynaSerError : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	int ErrorCode;
	AnsiString ErrorMessage;
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall ESynaSerError(const AnsiString Msg) : Sysutils::Exception(Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall ESynaSerError(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall ESynaSerError(int Ident)/* overload */ : Sysutils::Exception(Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall ESynaSerError(int Ident, const System::TVarRec * Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall ESynaSerError(const AnsiString Msg, int AHelpContext) : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall ESynaSerError(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall ESynaSerError(int Ident, int AHelpContext)/* overload */ : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall ESynaSerError(System::PResStringRec ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~ESynaSerError(void) { }
	#pragma option pop
	
};


class DELPHICLASS TBlockSerial;
class PASCALIMPLEMENTATION TBlockSerial : public System::TObject 
{
	typedef System::TObject inherited;
	
protected:
	THookSerialStatus FOnStatus;
	unsigned Fhandle;
	int FLastError;
	AnsiString FBuffer;
	bool FRaiseExcept;
	int FRecvBuffer;
	int FSendBuffer;
	int FModemWord;
	bool FRTSToggle;
	int FDeadlockTimeout;
	bool FInstanceActive;
	bool FTestDSR;
	bool FTestCTS;
	int FMaxLineLength;
	bool FLinuxLock;
	unsigned FEventHandle;
	bool __fastcall CanEvent(unsigned Event, int Timeout);
	void __fastcall DecodeCommError(unsigned Error);
	void __fastcall SetSizeRecvBuffer(int size);
	bool __fastcall GetDSR(void);
	void __fastcall SetDTRF(bool Value);
	bool __fastcall GetCTS(void);
	void __fastcall SetRTSF(bool Value);
	bool __fastcall GetCarrier(void);
	bool __fastcall GetRing(void);
	void __fastcall DoStatus(THookSerialReason Reason, const AnsiString Value);
	void __fastcall GetComNr(AnsiString Value);
	bool __fastcall PreTestFailing(void);
	bool __fastcall TestCtrlLine(void);
	
public:
	#pragma pack(push, 1)
	_DCB DCB;
	#pragma pack(pop)
	
	int FComNr;
	__fastcall TBlockSerial(void);
	__fastcall virtual ~TBlockSerial(void);
	AnsiString __fastcall GetVersion();
	void __fastcall CreateSocket(void);
	void __fastcall CloseSocket(void);
	void __fastcall Connect(AnsiString comport, int baud, int bits, char parity, int stop, bool softflow, bool hardflow);
	void __fastcall SetCommState(void);
	void __fastcall GetCommState(void);
	int __fastcall SendBuffer(void * buffer, int length);
	void __fastcall SendByte(Byte data);
	void __fastcall SendString(AnsiString data);
	int __fastcall RecvBuffer(void * buffer, int length);
	int __fastcall RecvBufferEx(void * buffer, int length, int timeout);
	AnsiString __fastcall RecvPacket(int Timeout);
	Byte __fastcall RecvByte(int timeout);
	AnsiString __fastcall RecvTerminated(int Timeout, const AnsiString Terminator);
	AnsiString __fastcall Recvstring(int timeout);
	int __fastcall WaitingData(void);
	int __fastcall WaitingDataEx(void);
	int __fastcall SendingData(void);
	void __fastcall EnableRTSToggle(bool value);
	void __fastcall EnableSoftRTSToggle(bool value);
	void __fastcall Flush(void);
	void __fastcall Purge(void);
	bool __fastcall CanRead(int Timeout);
	bool __fastcall CanWrite(int Timeout);
	bool __fastcall CanReadEx(int Timeout);
	int __fastcall ModemStatus(void);
	void __fastcall SetBreak(int Duration);
	AnsiString __fastcall ATCommand(AnsiString value);
	int __fastcall SerialCheck(int SerialResult);
	void __fastcall ExceptCheck(void);
	void __fastcall ErrorMethod(int ErrNumber);
	
__published:
	/*         class method */ static AnsiString __fastcall GetErrorDesc(TMetaClass* vmt, int ErrorCode);
	__property unsigned Handle = {read=Fhandle, write=Fhandle, nodefault};
	__property int LastError = {read=FLastError, nodefault};
	__property AnsiString LineBuffer = {read=FBuffer, write=FBuffer};
	__property bool RaiseExcept = {read=FRaiseExcept, write=FRaiseExcept, nodefault};
	__property int SizeRecvBuffer = {read=FRecvBuffer, write=SetSizeRecvBuffer, nodefault};
	__property THookSerialStatus OnStatus = {read=FOnStatus, write=FOnStatus};
	__property bool RTS = {write=SetRTSF, nodefault};
	__property bool CTS = {read=GetCTS, nodefault};
	__property bool DTR = {write=SetDTRF, nodefault};
	__property bool DSR = {read=GetDSR, nodefault};
	__property bool Carrier = {read=GetCarrier, nodefault};
	__property bool Ring = {read=GetRing, nodefault};
	__property bool InstanceActive = {read=FInstanceActive, nodefault};
	__property bool TestDSR = {read=FTestDSR, write=FTestDSR, nodefault};
	__property bool TestCTS = {read=FTestCTS, write=FTestCTS, nodefault};
	__property int MaxLineLength = {read=FMaxLineLength, write=FMaxLineLength, nodefault};
	__property int DeadlockTimeout = {read=FDeadlockTimeout, write=FDeadlockTimeout, nodefault};
	__property bool LinuxLock = {read=FLinuxLock, write=FLinuxLock, nodefault};
};


//-- var, const, procedure ---------------------------------------------------
#define LockfileDirectory "/var/lock"
static const Shortint PortIsClosed = 0xffffffff;
static const Word ErrAlreadyOwned = 0x2707;
static const Word ErrAlreadyInUse = 0x2708;
static const Word ErrWrongParameter = 0x2709;
static const Word ErrPortNotOpen = 0x270a;
static const Word ErrNoDeviceAnswer = 0x270b;
static const Word ErrMaxBuffer = 0x270c;
static const Word ErrTimeout = 0x270d;
static const Word ErrNotRead = 0x270e;
static const Word ErrFrame = 0x270f;
static const Word ErrOverrun = 0x2710;
static const Word ErrRxOver = 0x2711;
static const Word ErrRxParity = 0x2712;
static const Word ErrTxFull = 0x2713;
static const Shortint dcb_Binary = 0x1;
static const Shortint dcb_ParityCheck = 0x2;
static const Shortint dcb_OutxCtsFlow = 0x4;
static const Shortint dcb_OutxDsrFlow = 0x8;
static const Shortint dcb_DtrControlMask = 0x30;
static const Shortint dcb_DtrControlDisable = 0x0;
static const Shortint dcb_DtrControlEnable = 0x10;
static const Shortint dcb_DtrControlHandshake = 0x20;
static const Shortint dcb_DsrSensivity = 0x40;
static const Byte dcb_TXContinueOnXoff = 0x80;
static const Word dcb_OutX = 0x100;
static const Word dcb_InX = 0x200;
static const Word dcb_ErrorChar = 0x400;
static const Word dcb_NullStrip = 0x800;
static const Word dcb_RtsControlMask = 0x3000;
static const Shortint dcb_RtsControlDisable = 0x0;
static const Word dcb_RtsControlEnable = 0x1000;
static const Word dcb_RtsControlHandshake = 0x2000;
static const Word dcb_RtsControlToggle = 0x3000;
static const Word dcb_AbortOnError = 0x4000;
static const unsigned dcb_Reserveds = 0xffff8000;

}	/* namespace Synaser */
using namespace Synaser;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// SynaSer
