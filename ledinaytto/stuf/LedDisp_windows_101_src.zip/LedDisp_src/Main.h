//---------------------------------------------------------------------------

#ifndef MainH
#define MainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ActnCtrls.hpp>
#include <ActnList.hpp>
#include <ActnMan.hpp>
#include <ActnMenus.hpp>
#include <ComCtrls.hpp>
#include <ImgList.hpp>
#include <StdActns.hpp>
#include <ToolWin.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include "trayicon.h"
#include <Menus.hpp>
#include <Dialogs.hpp>

#include "SynaSer.hpp"
#include <NMHttp.hpp>
#include <Psock.hpp>

//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TActionManager *ActionManager1;
    TFileOpen *TextOpen;
    TFileExit *FileExit1;
    TActionMainMenuBar *ActionMainMenuBar1;
    TStatusBar *StatusBar1;
    TImageList *ImageList1;
    TMemo *Memo1;
    TRadioGroup *portGroup;
    TTimer *writeTextTimer;
    TSpeedButton *spScrollText;
    TTimer *readTextTimer;
    TPopupMenu *PopupMenu1;
    TMenuItem *Restore1;
    TMenuItem *N1;
    TMenuItem *Exit1;
    TTrayIcon *TrayIcon1;
    TAction *ToolsFontPalette;
    TAction *ToolsFontEditor;
    TAction *TextReadText;
    TAction *TextWriteText;
    TAction *FontReadFont;
    TAction *FontWriteFont;
    TAction *OptionsDisplayConf;
    TAction *FontClearAll;
    TAction *TextClear;
    TTimer *readFontTimer;
    TTimer *writeFontTimer;
    TBitBtn *buttonClear;
    TBitBtn *buttonRead;
    TBitBtn *buttonWrite;
    TBitBtn *buttonBrowse;
    TCheckBox *cbPlayFromFile;
    TOpenDialog *OpenDialog1;
    TAction *OptionsProgramConf;
    TCheckBox *cbUseFrameString;
    TFileSaveAs *TextSaveAs;
    TFileOpen *FontOpen;
    TFileSaveAs *FontSaveAs;
    TAction *FontSave;
    TAction *TextSave;
    TAction *HelpAbout;
    TBitBtn *buttonOpen;
    TBitBtn *buttonSave;
    TActionToolBar *ActionToolBar1;
    TCheckBox *cbPlayFromWeb;
    TEdit *editWebAddress;
    TCheckBox *cbLogReader;
    TCheckBox *cbSkipLines;
    TNMHTTP *NMHTTP1;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall spScrollTextClick(TObject *Sender);
    void __fastcall readTextTimerTimer(TObject *Sender);
    void __fastcall writeTextTimerTimer(TObject *Sender);
    void __fastcall Restore1Click(TObject *Sender);
    void __fastcall Exit1Click(TObject *Sender);
    void __fastcall TrayIcon1Restore(TObject *Sender);
    void __fastcall ProgramMinimize(TObject *Sender);
    void __fastcall ToolsFontPaletteExecute(TObject *Sender);
    void __fastcall ToolsFontEditorExecute(TObject *Sender);
    void __fastcall TextReadTextExecute(TObject *Sender);
    void __fastcall TextWriteTextExecute(TObject *Sender);
    void __fastcall TextClearExecute(TObject *Sender);
    void __fastcall FontClearAllExecute(TObject *Sender);
    void __fastcall FontReadFontExecute(TObject *Sender);
    void __fastcall readFontTimerTimer(TObject *Sender);
    void __fastcall FontWriteFontExecute(TObject *Sender);
    void __fastcall writeFontTimerTimer(TObject *Sender);
    void __fastcall Memo1Change(TObject *Sender);
    void __fastcall Memo1KeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
    void __fastcall buttonBrowseClick(TObject *Sender);
    void __fastcall cbPlayFromFileClick(TObject *Sender);
    void __fastcall TextOpenAccept(TObject *Sender);
    void __fastcall TextSaveAsAccept(TObject *Sender);
    void __fastcall TextSaveExecute(TObject *Sender);
    void __fastcall FontSaveAsAccept(TObject *Sender);
    void __fastcall FontOpenAccept(TObject *Sender);
    void __fastcall FontSaveExecute(TObject *Sender);
    void __fastcall FormActivate(TObject *Sender);
    void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall HelpAboutExecute(TObject *Sender);
    void __fastcall cbPlayFromWebClick(TObject *Sender);
    void __fastcall cbLogReaderClick(TObject *Sender);
    void __fastcall NMHTTP1Success(CmdType Cmd);
private:	// User declarations
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);

    bool __fastcall connectSerialPort(void);

    void __fastcall disableForm(void);
    void __fastcall enableForm(void);
    bool __fastcall getString(AnsiString src,
                              AnsiString format_str,
                              AnsiString &dest);
    //bool __fastcall parseAddress(AnsiString address,
    //                             AnsiString &host,
    //                             AnsiString &page);

    bool mode_scroll_text;
    AnsiString scrollfilename;
    AnsiString textfilename;
    AnsiString fontfilename;
    /*pOpenComm       *OpenComm;
    pWriteToComm    *WriteToComm;
    pReadFromComm   *ReadFromComm;
    pShutDownComm   *ShutDownComm;
    pFlushComm      *FlushComm;
    pShowMessages   *ShowMessages;*/
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
