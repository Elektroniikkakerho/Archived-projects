//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "FontPalette.h"
#include "FontEditor.h"
#include "Main.h"

__fastcall TFontImage::TFontImage(TComponent *Owner, int _index) :
    TImage(Owner),
    index(_index),
    OnFontLeftClick(NULL),
    OnFontRightClick(NULL)
{
    OnMouseDown = ImageMouseDown;
}


void __fastcall TFontImage::ImageMouseDown(System::TObject* Sender,
                                   TMouseButton Button,
                                   Classes::TShiftState Shift,
                                   int X, int Y)
{
    if (Button == mbLeft && OnFontLeftClick) OnFontLeftClick(index);
    if (Button == mbRight && OnFontRightClick) OnFontRightClick(index);
}


//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFonts *Fonts;
//---------------------------------------------------------------------------
__fastcall TFonts::TFonts(TComponent* Owner)
    : TForm(Owner),
    fgColor(clRed),
    bgColor(clWhite),
    cursorColor(clBlue),
    cursor_index(1),
    cursor_visible(false),
    Modified(false)
{
    int index=0;
    for(int y=0; y<8; y++) {
        for(int x=0; x<32; x++, index++) {
            if (index >= CHARACTERS) return;
            
            fontImages[index]=new TFontImage(this,index);
            fontImages[index]->Parent = this;
            fontImages[index]->OnFontLeftClick = FontImageLeftClick;
            fontImages[index]->OnFontRightClick = FontImageRightClick;
            fontImages[index]->Hint = AnsiString("|") + AnsiString(index) + "  '" + AnsiString((char)index) + "'";

            fontImages[index]->Left = x*18 + 10;
            fontImages[index]->Top = y*24 + 10;
            fontImages[index]->Width = 15;
            fontImages[index]->Height = 21;

            fontImages[index]->Canvas->Pen->Color=fgColor;

            if (index < FIRST_VISIBLE_CHAR) fontImages[index]->Visible=false;

            charWidth[index]=6;
        }
    }
}
//---------------------------------------------------------------------------


void __fastcall TFonts::FontImageLeftClick(int index) {
    Form1->SetFocus();
    Form1->Memo1->SetSelTextBuf(AnsiString((char)index).c_str());
}


void __fastcall TFonts::FontImageRightClick(int index) {
    bool mod = Fonts->Modified;
    if (!Editor->Visible) Editor->Show();
    Editor->UpDownCharCode->Position = index;
    Fonts->setCursor(index);
    Fonts->Modified = mod;
}


void __fastcall TFonts::getFont5x7(int index, bool dest[5][7]) {
    if (index < 0 || index >= CHARACTERS) {
        for(int y=0; y<7; y++) for(int x=0; x<5; x++) dest[x][y]=false;
        return;
    }

    for(int y=0; y<7; y++) {
        for(int x=0; x<5; x++) {
            if (fontImages[index]->Canvas->Pixels[3*x][3*y] == fgColor) {
                dest[x][y]=true;
            }
            else dest[x][y]=false;
        }
    }
}

void __fastcall TFonts::setFont5x7(int index, const bool src[5][7]) {
    if (index < 0 || index >= CHARACTERS) return;

    for(int y=0; y<7; y++) {
        for(int x=0; x<5; x++) {
            TColor color=bgColor;
            if (src[x][y]) color=fgColor;
            for (int dy=0; dy<3; dy++) {
                fontImages[index]->Canvas->Pixels[3*x][3*y+dy] = color;
                fontImages[index]->Canvas->Pixels[3*x+1][3*y+dy] = color;
                fontImages[index]->Canvas->Pixels[3*x+2][3*y+dy] = color;
            }
        }
    }
    
    Modified = true;
}

void __fastcall TFonts::clearAll(void) {
    TRect rect=TRect(0,0,15,21);
    for(int i=0; i<CHARACTERS; i++) {
        fontImages[i]->Canvas->Brush->Color=bgColor;
        fontImages[i]->Canvas->FillRect(rect);
        charWidth[i]=6;
    }
}


void __fastcall TFonts::drawCursor(TColor color) {
    int x = Fonts->fontImages[cursor_index]->Left;
    int y = Fonts->fontImages[cursor_index]->Top;
    int x1 = x-2;
    int y1 = y-2;
    int x2 = x+16;
    int y2 = y+22;

    Fonts->Canvas->Pen->Color = color;
    Fonts->Canvas->MoveTo(x1,y1);
    Fonts->Canvas->LineTo(x2,y1);
    Fonts->Canvas->LineTo(x2,y2);
    Fonts->Canvas->LineTo(x1,y2);
    Fonts->Canvas->LineTo(x1,y1);
}


void __fastcall TFonts::showCursor() {
    cursor_visible = true;
    drawCursor(cursorColor);
}

void __fastcall TFonts::hideCursor() {
    cursor_visible = false;
    drawCursor(clBtnFace);
}


void __fastcall TFonts::setCursor(int index) {
    if (index < FIRST_VISIBLE_CHAR) index = FIRST_VISIBLE_CHAR;
    else if (index >= CHARACTERS) index = CHARACTERS-1;
    hideCursor();
    cursor_index = index;
    showCursor();
    Form1->StatusBar1->Panels->Items[0]->Text = AnsiString(index) + "  '" + AnsiString((char)index) + "'";
}


void __fastcall TFonts::FormPaint(TObject *Sender)
{
    if (cursor_visible) drawCursor(cursorColor);
}
//---------------------------------------------------------------------------

void __fastcall TFonts::FormKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
    switch (Key) {
        case VK_LEFT:   setCursor(cursor_index-1); break;
        case VK_RIGHT:  setCursor(cursor_index+1); break;
        case VK_UP:     setCursor(cursor_index-32); break;
        case VK_DOWN:   setCursor(cursor_index+32); break;
        case VK_HOME:   setCursor(FIRST_VISIBLE_CHAR); break;
        case VK_END:    setCursor(CHARACTERS-1); break;
        case VK_SPACE:
        case VK_RETURN: FontImageLeftClick(cursor_index); break;
    }
}
//---------------------------------------------------------------------------

bool __fastcall TFonts::SaveToFile(const AnsiString &filename) {
    TFileStream *out = NULL;
    try {
        out = new TFileStream(filename,fmCreate | fmShareExclusive);
    }
    catch(...) {
        delete out;
        return false;
    }

    for(int i=0; i<CHARACTERS; i++) {
        //fontImages[i]->Picture->Bitmap->SaveToStream(out);
        bool ch[5][7];
        getFont5x7(i,ch);
        out->Write(ch,sizeof(ch));
        out->Write(&charWidth[i],sizeof(int));
    }

    //Modified = false;
    
    delete out;
    return true;
}


bool __fastcall TFonts::LoadFromFile(const AnsiString &filename) {
    TFileStream *in = NULL;
    try {
        in = new TFileStream(filename,fmOpenRead | fmShareDenyWrite);
    }
    catch(...) {
        delete in;
        return false;
    }

    for(int i=0; i<CHARACTERS; i++) {
        //TPicture *pic = new TPicture();
        //pic->Bitmap->LoadFromStream(in);
        //fontImages[i]->Picture = pic;
        //delete pic;
        bool ch[5][7];
        in->Read(ch,sizeof(ch));
        setFont5x7(i,ch);
        in->Read(&charWidth[i],sizeof(int));
    }
    
    //Modified = false;

    delete in;
    return true;
}

