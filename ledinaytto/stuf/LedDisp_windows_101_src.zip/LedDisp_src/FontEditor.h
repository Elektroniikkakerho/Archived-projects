//---------------------------------------------------------------------------

#ifndef FontEditorH
#define FontEditorH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
//---------------------------------------------------------------------------
class TEditor : public TForm
{
__published:	// IDE-managed Components
    TEdit *EditCharCode;
    TUpDown *UpDownCharCode;
    TEdit *EditCharASCII;
    TUpDown *UpDownWidth;
    TEdit *EditCharWidth;
    TLabel *Label1;
    TButton *buttonClear;
    TButton *buttonClearAll;
    TPanel *Panel2;
    TPanel *Panel1;
    TBitBtn *buttonPalette;
    TImage *PixelImage;
    void __fastcall buttonPaletteClick(TObject *Sender);
    void __fastcall buttonClearClick(TObject *Sender);
    void __fastcall EditCharCodeChange(TObject *Sender);
    void __fastcall EditCharASCIIChange(TObject *Sender);
    void __fastcall EditCharWidthChange(TObject *Sender);
    void __fastcall FormActivate(TObject *Sender);
private:	// User declarations
    TSpeedButton *fontEditArray[5][7];
    void __fastcall fontEditArrayChanged(TObject *Sender);
public:		// User declarations
    __fastcall TEditor(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TEditor *Editor;
//---------------------------------------------------------------------------
#endif
