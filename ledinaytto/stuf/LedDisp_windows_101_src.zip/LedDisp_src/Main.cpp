//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Main.h"
#include "Operation.h"
#include "FontPalette.h"
#include "FontEditor.h"
#include "About.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "trayicon"
#pragma resource "*.dfm"

#pragma link "SynaSer"

TForm1 *Form1;

TBlockSerial *ser = NULL;

AnsiString uart_buffer;
AnsiString command;

AnsiString host;
AnsiString page;

int send_index;
int col_index;
int font_index;
AnsiString prev_str;
int filepos=0;

bool start_found;
bool command_sent;
bool page_ready;

unsigned char read_char[5];

#define QUICK_TIMEOUT   5

#define END_SPACE_COUNT  15

#define MAX_PAGE_SIZE 1024*64

#define MIN_BURST_SIZE 5

#define CMD_START           	0xFF
#define CMD_GET_FONT        	0xFE
#define CMD_GET_TEXT        	0xFD
#define MESSAGE_FONT_START		0xDD
#define MESSAGE_TEXT_START		0x00
#define TEXT_END            	0x00


#define TOTAL_BLOCKS        8
#define FONT_START_BLOCK    3
#define MAX_TEXT_LENGTH     (FONT_START_BLOCK*256 - 1)
#define FONT_MAX_COUNT      (((TOTAL_BLOCKS-FONT_START_BLOCK)*256)/5)
//---------------------------------------------------------------------------


__fastcall TForm1::TForm1(TComponent* Owner) : TForm(Owner)
{
    Application->OnMinimize=ProgramMinimize;
    StatusBar1->Panels->Items[1]->Text = "";
    scrollfilename = "";

    ser = new TBlockSerial;
    ser->RaiseExcept=false;
    NMHTTP1->InputFileMode = false;
}
//---------------------------------------------------------------------------


void __fastcall TForm1::FormCreate(TObject *Sender)
{
    //Parse command line params:
    for (int i=1;i<=ParamCount();i++) {
        if (LowerCase(ParamStr(i)) == "start_minimized") {
            WindowState = wsMinimized;
        }
        else if (LowerCase(ParamStr(i)) == "port=com2") {
            portGroup->ItemIndex=1;
        }
        else if (LowerCase(ParamStr(i)).SubString(1,5) == "play=") {
            scrollfilename = ParamStr(i).SubString(6,ParamStr(i).Length()-5);
        }
        else if (LowerCase(ParamStr(i)).SubString(1,5) == "text=") {
            textfilename = ParamStr(i).SubString(6,ParamStr(i).Length()-5);
        }
        else if (LowerCase(ParamStr(i)) == "use_frame_string") {
            cbUseFrameString->Checked = true;
        }
        else if (LowerCase(ParamStr(i)) == "log_reader") {
            cbLogReader->Checked = true;
        }
        else if (LowerCase(ParamStr(i)) == "skip_lines") {
            cbSkipLines->Checked = true;
        }
    }

    //If we got a file to be loaded into the editor...
    if (textfilename != "") {
        try {
            Memo1->Lines->LoadFromFile(textfilename);
        }
        catch(EFOpenError &E) {
            MessageDlg(E.Message + textfilename + " !",mtError,TMsgDlgButtons() << mbOK, 0);
            textfilename = "";
        }
        catch(...) { }

        if (textfilename != "") {
            int bksl = textfilename.LastDelimiter("\\");
            Form1->Caption = AnsiString(" LedDisp - ")
                + textfilename.SubString(bksl+1,textfilename.Length()-bksl);
            Memo1->Modified = false;
        }
    }

    //If we are told to play the text from a file...
    if (scrollfilename != "") {
        cbPlayFromFile->Checked = true;
        spScrollText->Down=true;
        spScrollTextClick(this);
    }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{
    delete ser;
}

//---------------------------------------------------------------------------

//Function creates a serial port connection to the port indicated by
// the port selection group box.
//Function returns true if the operation was succesful.
bool __fastcall TForm1::connectSerialPort(void) {
    AnsiString port = portGroup->Items->operator [](portGroup->ItemIndex);
    ser->Connect(port,9600,8,'N',0,false,false);
    if (ser->LastError != 0) {
        AnsiString message="Cannot open port [" + port + "]:\n";
        message += ser->GetErrorDesc(NULL,ser->LastError);
        MessageDlg(message.c_str(),mtError,TMsgDlgButtons() << mbOK, 0);
        return false;
    }
    return true;
}

//---------------------------------------------------------------------------

//Disables the form. Called before communicating with the display.
void __fastcall TForm1::disableForm(void) {
    spScrollText->Enabled=false;
    cbPlayFromFile->Enabled=false;
    cbPlayFromWeb->Enabled=false;
    cbUseFrameString->Enabled=false;
    cbLogReader->Enabled=false;
    cbSkipLines->Enabled=false;
    editWebAddress->Enabled=false;
    buttonBrowse->Enabled=false;
    buttonWrite->Enabled=false;
    buttonRead->Enabled=false;
    buttonClear->Enabled=false;
    buttonOpen->Enabled=false;
    buttonSave->Enabled=false;
    portGroup->Enabled=false;
    ActionMainMenuBar1->Enabled=false;
    ActionToolBar1->Enabled=false;
}

//---------------------------------------------------------------------------

//Restores the form. Called when finished communicating with the display.
void __fastcall TForm1::enableForm(void) {
    spScrollText->Enabled=true;
    cbPlayFromFile->Enabled=true;
    cbPlayFromWeb->Enabled=true;
    if (cbPlayFromFile->Checked || cbPlayFromWeb->Checked) {
        cbUseFrameString->Enabled = true;
    }
    if (cbPlayFromFile->Checked) {
        cbLogReader->Enabled=true;
        if (cbLogReader->Checked) {
            cbSkipLines->Enabled=true;
        }
    }
    editWebAddress->Enabled=true;
    buttonBrowse->Enabled=true;
    buttonWrite->Enabled=true;
    buttonRead->Enabled=true;
    buttonClear->Enabled=true;
    buttonOpen->Enabled=true;
    buttonSave->Enabled=true;
    portGroup->Enabled=true;
    ActionMainMenuBar1->Enabled=true;
    ActionToolBar1->Enabled=true;
}

//---------------------------------------------------------------------------


//The function returns a part of the given string on ground of the format
// string. The format string contains the string "%s%" and two optional
// substrings before and after the part "%s%" (prefix and postfix).
//The function finds the first occurence of the prefix in the given string and
// then the following occurence of the postfix. If they are found, the function
// picks the string between the prefix and the postfix and returns with that
// string in the &dest.
//If the prefix is empty, then the final string starts at the beginning
// of the original string. If the postfix is empty, the string returned ends
// at the end of the original string.
//The function returns true if the operation was succesful.
bool __fastcall TForm1::getString(AnsiString src,
                              AnsiString format_str,
                              AnsiString &dest) {
    AnsiString prefix;
    AnsiString postfix;
    int start_index=1, end_index = src.Length()+1;
    int mark_index = format_str.Pos("%s%");

    if (mark_index == 0) return false;

    prefix = format_str.SubString(1,mark_index-1);
    postfix = format_str.SubString(mark_index+3,
                                   format_str.Length()-mark_index-2);
    if (prefix.Length() > 0) {
        start_index = src.Pos(prefix);
        if (start_index == 0) return false;
        start_index += prefix.Length();
    }
    if (postfix.Length() > 0) {
        AnsiString temp = src.SubString(start_index,
                                        src.Length()-start_index+1);
        end_index = temp.Pos(postfix);
        if (end_index == 0) return false;
        end_index += (start_index - 1);
    }

    dest = src.SubString(start_index,end_index-start_index);
    
    return true;
}

//---------------------------------------------------------------------------

/*
//Function gets an url ("http://host/page" or "host/page") and returns with
// the hostname in the &host and the page name in the &page.
//Function returns true if the operation was succesful.
bool __fastcall TForm1::parseAddress(AnsiString address,
                                     AnsiString &host,
                                     AnsiString &page) {
    address = address.Trim();
    int prefix_index = UpperCase(address).Pos("HTTP://");
    if (prefix_index == 1) address = address.SubString(8,address.Length()-7);
    else if (prefix_index != 0) return false;

    int slash_index = address.Pos("/");
    if (slash_index == 0) return false;

    host = address.SubString(1,slash_index-1);
    page = address.SubString(slash_index,address.Length()-slash_index+1);
    return true;
}
*/

//---------------------------------------------------------------------------


void __fastcall TForm1::Exit1Click(TObject *Sender)
{
    Close();
}

//---------------------------------------------------------------------------

//Restores the program from the system tray:
void __fastcall TForm1::Restore1Click(TObject *Sender)
{
    TrayIcon1->Restore();
}

//---------------------------------------------------------------------------

//Called automatically when the program is restored from the system tray
void __fastcall TForm1::TrayIcon1Restore(TObject *Sender)
{
    if (TrayIcon1->Visible) TrayIcon1->Visible=false;
}

//---------------------------------------------------------------------------

//Called automatically when the program is minimized.
//Shows the tray icon and hides the program.
void __fastcall TForm1::ProgramMinimize(TObject *Sender)
{
    if (!TrayIcon1->Visible) TrayIcon1->Visible=true;
    TrayIcon1->Minimize();
}
//---------------------------------------------------------------------------

//Shows the font palette
void __fastcall TForm1::ToolsFontPaletteExecute(TObject *Sender)
{
    Fonts->Show();
}

//---------------------------------------------------------------------------

//Shows the font editor
void __fastcall TForm1::ToolsFontEditorExecute(TObject *Sender)
{
    bool mod = Fonts->Modified; //Save Modified flag, because the first call
    Editor->Show();             // of Editor->Show() causes the flag to be set
    Fonts->Modified = mod;      //Restore flag
}
//---------------------------------------------------------------------------


//Shows the confirmation dialog and clears the font palette.
void __fastcall TForm1::FontClearAllExecute(TObject *Sender)
{
    if (Fonts->Modified) {
        int resp = MessageDlg("Font has been modified. Save?",
                              mtConfirmation,TMsgDlgButtons() << mbYes << mbNo << mbCancel,0);
        switch(resp) {
            case mrYes:
                FontSaveExecute(this);
                break;
            case mrCancel:
                return;
        }
    }

    Fonts->clearAll();
    if (Editor->Visible) Editor->buttonClearClick(this);
    fontfilename = "";
    Editor->Caption = "Font Editor";
    Fonts->Caption = "Font Palette";
    Editor->EditCharCodeChange(this);
    Fonts->Modified = false;
}


//---------------------------------------------------------------------------


//Shows the confirmation dialog and clears the text editor
void __fastcall TForm1::TextClearExecute(TObject *Sender)
{
    if (Memo1->Modified) {
        int resp = MessageDlg("Text has been modified. Save?",
                              mtConfirmation,TMsgDlgButtons() << mbYes << mbNo << mbCancel,0);
        switch(resp) {
            case mrYes:
                TextSaveExecute(this);
                break;
            case mrCancel:
                return;
        }
    }

    Memo1->Clear();
    textfilename = "";
    Form1->Caption = " LedDisp";
    StatusBar1->Panels->Items[1]->Text = "0";
}

//---------------------------------------------------------------------------

//Called whenever the contents of the text editor is changed
void __fastcall TForm1::Memo1Change(TObject *Sender)
{
    //Update the status bar with the new text length
    StatusBar1->Panels->Items[1]->Text = AnsiString(Memo1->Text.Length());
    //If the font palette is visible, move the font cursor on the same
    //character that is on the left side of the text cursor.
    if (Fonts->Visible) {
        int cursor = Form1->Memo1->SelStart;
        //Cannot get character on the left side if in the beginning...
        if (cursor == 0) {
            Fonts->hideCursor();
            Form1->StatusBar1->Panels->Items[0]->Text = AnsiString("");
            return;
        }
        AnsiString text = Form1->Memo1->Text;
        unsigned char c = (unsigned char) text[cursor];
        Fonts->setCursor(c);
    }
}

//---------------------------------------------------------------------------

//Called whenever a key is released when the text editor is active.
//Calls the function above to update the font cursor.
void __fastcall TForm1::Memo1KeyUp(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
    Memo1Change(this);
}
//---------------------------------------------------------------------------


//Called when the button "Browse..." is clicked. Shows an open-dialog
//for the user to choose a file to be played.
void __fastcall TForm1::buttonBrowseClick(TObject *Sender)
{
    if (OpenDialog1->Execute()) {
        scrollfilename = OpenDialog1->FileName;
        cbPlayFromFile->Checked = true;
        cbPlayFromWeb->Checked=false;
        cbUseFrameString->Enabled = true;
        cbLogReader->Enabled = true;
        if (cbLogReader->Checked) cbSkipLines->Enabled=true;
    }
    else {
        cbPlayFromFile->Checked = false;
        cbUseFrameString->Enabled = false;
        cbLogReader->Enabled=false;
        cbSkipLines->Enabled=false;
        scrollfilename = "";
    }
}
//---------------------------------------------------------------------------


//If the check box "Play from file" is clicked, this function is called.
//If the file name hasn't been specified, the function calls
//the function buttonBrowseClick (above).
void __fastcall TForm1::cbPlayFromFileClick(TObject *Sender)
{
    if (cbPlayFromFile->Checked) {
        if (scrollfilename == "") buttonBrowseClick(this);
        else {
            cbPlayFromWeb->Checked=false;
            cbUseFrameString->Enabled = true;
            cbLogReader->Enabled = true;
            if (cbLogReader->Checked) cbSkipLines->Enabled=true;
        }
    }
    else {
        cbUseFrameString->Enabled = false;
        cbLogReader->Enabled=false;
        cbSkipLines->Enabled=false;
    }
}
//---------------------------------------------------------------------------


//Called when the user has chosen a file to be opened in the text editor.
//Asks the user whether the previous file is to be saved and loads the new file.
void __fastcall TForm1::TextOpenAccept(TObject *Sender)
{
    if (Memo1->Modified) {
        int resp = MessageDlg("Text has been modified. Save?",
                              mtConfirmation,TMsgDlgButtons() << mbYes << mbNo << mbCancel,0);
        switch(resp) {
            case mrYes:
                TextSaveExecute(this);
                break;
            case mrCancel:
                return;
        }
    }

    textfilename = TextOpen->Dialog->FileName;
    Memo1->Lines->LoadFromFile(textfilename);
    int bksl = textfilename.LastDelimiter("\\");
    Form1->Caption = AnsiString(" LedDisp - ")
                   + textfilename.SubString(bksl+1,textfilename.Length()-bksl);
    Memo1->Modified = false;
}
//---------------------------------------------------------------------------


//Called when the user has chosen a file in which the contents of the text
//editor is to be saved.
void __fastcall TForm1::TextSaveAsAccept(TObject *Sender)
{
    textfilename = TextSaveAs->Dialog->FileName;
    Memo1->Lines->SaveToFile(textfilename);
    int bksl = textfilename.LastDelimiter("\\");
    Form1->Caption = AnsiString(" LedDisp - ")
                   + textfilename.SubString(bksl+1,textfilename.Length()-bksl);
    Form1->StatusBar1->Panels->Items[0]->Text = "File saved";
    Memo1->Modified = false;
}
//---------------------------------------------------------------------------

//Called if the user presses the "Save text" button or chooses Text->Save
//in the menu. Opens the Save as dialog if the file name hasn't been specified.
void __fastcall TForm1::TextSaveExecute(TObject *Sender)
{
    if (textfilename != "") {
        Memo1->Lines->SaveToFile(textfilename);
        Form1->StatusBar1->Panels->Items[0]->Text = "File saved";
        Memo1->Modified = false;
    }
    else TextSaveAs->Execute();
}
//---------------------------------------------------------------------------


//Called when the user has chosen a font file to be loaded in the palette.
//Asks the user whether the previous file is to be saved and loads the new file.
void __fastcall TForm1::FontOpenAccept(TObject *Sender)
{
    if (Fonts->Modified) {
        int resp = MessageDlg("Font has been modified. Save?",
                              mtConfirmation,TMsgDlgButtons() << mbYes << mbNo << mbCancel,0);
        switch(resp) {
            case mrYes:
                FontSaveExecute(this);
                break;
            case mrCancel:
                return;
        }
    }

    if (!Fonts->LoadFromFile(FontOpen->Dialog->FileName)) {
        MessageDlg("Cannot open file!",mtError,TMsgDlgButtons() << mbOK, 0);
        return;
    }
    fontfilename = FontOpen->Dialog->FileName;

    int bksl = fontfilename.LastDelimiter("\\");
    Editor->Caption = AnsiString("Font Editor - ")
                   + fontfilename.SubString(bksl+1,fontfilename.Length()-bksl);
    Fonts->Caption = AnsiString("Font Palette - ")
                   + fontfilename.SubString(bksl+1,fontfilename.Length()-bksl);

    Editor->EditCharCodeChange(this);   //Causes editor to refresh font
    Fonts->Modified = false;
}
//---------------------------------------------------------------------------


//Called when the user has chosen a file in which the font is to be saved.
void __fastcall TForm1::FontSaveAsAccept(TObject *Sender)
{
    if (!Fonts->SaveToFile(FontSaveAs->Dialog->FileName)) {
        MessageDlg("Cannot save file!",mtError,TMsgDlgButtons() << mbOK, 0);
        return;
    }
    fontfilename = FontSaveAs->Dialog->FileName;

    int bksl = fontfilename.LastDelimiter("\\");
    Editor->Caption = AnsiString("Font Editor - ")
                   + fontfilename.SubString(bksl+1,fontfilename.Length()-bksl);
    Fonts->Caption = AnsiString("Font Palette - ")
                   + fontfilename.SubString(bksl+1,fontfilename.Length()-bksl);

    Form1->StatusBar1->Panels->Items[0]->Text = "Font saved";
    Fonts->Modified = false;
}
//---------------------------------------------------------------------------

//Called if the user chooses Font->Save in the menu.
//Opens the Save as dialog if the file name hasn't been specified.
void __fastcall TForm1::FontSaveExecute(TObject *Sender)
{
    if (fontfilename != "") {
        if (!Fonts->SaveToFile(fontfilename)) {
            MessageDlg("Cannot save file!",mtError,TMsgDlgButtons() << mbOK, 0);
        }
        else Form1->StatusBar1->Panels->Items[0]->Text = "Font saved";
        Fonts->Modified = false;
    }
    else FontSaveAs->Execute();

}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormActivate(TObject *Sender)
{
    int cursor = Form1->Memo1->SelStart;
    if (cursor == 0) Fonts->hideCursor();
    else Fonts->setCursor(Form1->Memo1->Text[cursor]);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCloseQuery(TObject *Sender, bool &CanClose)
{
    if (Memo1->Modified) {
        int resp = MessageDlg("Text has been modified. Save?",
                              mtConfirmation,TMsgDlgButtons() << mbYes << mbNo << mbCancel,0);
        switch(resp) {
            case mrYes:
                TextSaveExecute(this);
                break;
            case mrCancel:
                CanClose = false;
                return;
        }
    }

    if (Fonts->Modified) {
        int resp = MessageDlg("Font has been modified. Save?",
                              mtConfirmation,TMsgDlgButtons() << mbYes << mbNo << mbCancel,0);
        switch(resp) {
            case mrYes:
                FontSaveExecute(this);
                break;
            case mrCancel:
                CanClose = false;
                break;
        }
    }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::HelpAboutExecute(TObject *Sender)
{
    AboutBox->Show();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::cbPlayFromWebClick(TObject *Sender)
{
    if (cbPlayFromWeb->Checked) {
        cbPlayFromFile->Checked=false;
        cbUseFrameString->Enabled=true;
    }
    else cbUseFrameString->Enabled=false;
}
//---------------------------------------------------------------------------


void __fastcall TForm1::cbLogReaderClick(TObject *Sender)
{
    if (cbLogReader->Checked) cbSkipLines->Enabled=true;
    else cbSkipLines->Enabled=false;
}


//---------------------------------------------------------------------------


void __fastcall TForm1::spScrollTextClick(TObject *Sender)
{
    if (spScrollText->Down) {
        if (connectSerialPort()) {
            send_index = 0;
            if (cbPlayFromFile->Checked) {
                prev_str = "";
                uart_buffer = "";
                filepos = 0;
            }
            else if (cbPlayFromWeb->Checked) {
                uart_buffer = "";
                page_ready = false;
            }
            else uart_buffer = Memo1->Text;
            
            mode_scroll_text=true;
            command_sent=true;
            writeTextTimer->Interval=500;

            cbPlayFromFile->Enabled=false;
            cbPlayFromWeb->Enabled=false;
            cbUseFrameString->Enabled=false;
            cbLogReader->Enabled=false;
            cbSkipLines->Enabled=false;
            editWebAddress->Enabled=false;
            buttonBrowse->Enabled=false;
            buttonWrite->Enabled=false;
            buttonRead->Enabled=false;
            buttonClear->Enabled=false;
            buttonOpen->Enabled=false;
            buttonSave->Enabled=false;
            portGroup->Enabled=false;
            ActionMainMenuBar1->Enabled=false;
            ActionToolBar1->Enabled=false;
            writeTextTimer->Enabled=true;
        }
        else spScrollText->Down=false;
    }
    else {
        writeTextTimer->Enabled=false;
        ser->CloseSocket();

        cbPlayFromFile->Enabled=true;
        cbPlayFromWeb->Enabled=true;
        if (cbPlayFromFile->Checked || cbPlayFromWeb->Checked) {
            cbUseFrameString->Enabled=true;
        }
        if (cbPlayFromFile->Checked) {
            cbLogReader->Enabled=true;
            if (cbLogReader->Checked) {
                cbSkipLines->Enabled=true;
            }
        }
        editWebAddress->Enabled=true;
        buttonBrowse->Enabled=true;
        portGroup->Enabled=true;
        buttonWrite->Enabled=true;
        buttonRead->Enabled=true;
        buttonClear->Enabled=true;
        buttonOpen->Enabled=true;
        buttonSave->Enabled=true;
        ActionMainMenuBar1->Enabled=true;
        ActionToolBar1->Enabled=true;
        Enabled = true;
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::TextWriteTextExecute(TObject *Sender)
{
    if (!connectSerialPort()) return;

    command = AnsiString((char)CMD_START) + (char)MESSAGE_TEXT_START;

    uart_buffer = Memo1->Text.SubString(0,MAX_TEXT_LENGTH);
    send_index = 0;
    mode_scroll_text=false;
    command_sent=false;
    writeTextTimer->Interval=50;

    OperationForm->showOperation("Writing text...","Write");
    disableForm();
    writeTextTimer->Enabled=true;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::NMHTTP1Success(CmdType Cmd)
{
    page_ready = true;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::writeTextTimerTimer(TObject *Sender)
{
    writeTextTimer->Enabled=false;

    int read_count = ser->WaitingData();
    char *buff=new char[read_count+1];

    ser->RecvBuffer(buff,read_count);

    if ((read_count > 0) && (buff[read_count-1] >= MIN_BURST_SIZE)) {
        if (!command_sent) {
            ser->SendBuffer(command.c_str(),2);
            ser->Flush();
            command_sent=true;
        }
        else {
            int burst = buff[read_count-1];
            if (send_index + burst <= uart_buffer.Length()) {
                ser->SendBuffer(uart_buffer.c_str()+send_index,burst);
                send_index += burst;
            }
            else {
                burst=uart_buffer.Length()-send_index;
                ser->SendBuffer(uart_buffer.c_str()+send_index,burst);
                if (mode_scroll_text) {
                    send_index = 0;
                    if (cbPlayFromFile->Checked) {
                        AnsiString str;
                        if (cbLogReader->Checked) {
                            if (cbSkipLines->Checked) {
                                char *buf = new char[501];
                                TFileStream *infile = new TFileStream(scrollfilename, fmOpenRead | fmShareDenyNone);
                                infile->Seek(-499,soFromEnd);
                                int bytes = infile->Read(buf,500);
                                buf[bytes] = '\0';
                                str = buf;
                                delete[] buf;
                                delete infile;

                                int lastrowstart = str.Length();

                                while(true) {
                                    if (lastrowstart < 1) {
                                        str = " ";
                                        break;
                                    }
                                    int prev_start = lastrowstart;
                                    lastrowstart = str.SubString(1,lastrowstart).LastDelimiter("\n\r");
                                    if (!lastrowstart) lastrowstart = 1;
                                    if (lastrowstart == prev_start) {
                                        lastrowstart--;
                                    }
                                    else {
                                        str = str.SubString(lastrowstart+1, prev_start-lastrowstart);
                                        break;
                                    }
                                }

                                if (str == prev_str) str = " ";
                                else {
                                    prev_str = str;
                                    str += AnsiString::StringOfChar(' ',END_SPACE_COUNT);
                                }

                            } //cbSkipLines->Checked
                            else {
                                char *buf = new char[501];
                                TFileStream *infile = new TFileStream(scrollfilename, fmOpenRead | fmShareDenyNone);

                                if (filepos > infile->Size) filepos = infile->Size;
                                infile->Seek(filepos,soFromBeginning);

                                int bytes = infile->Read(buf,500);
                                buf[bytes] = '\0';
                                str = buf;

                                int nlpos = str.Pos("\n");
                                if (nlpos > 0) {
                                    str = str.SubString(1,nlpos-1);
                                    str += AnsiString::StringOfChar(' ',END_SPACE_COUNT);
                                    filepos += nlpos;
                                }
                                else {
                                    filepos += str.Length();
                                    if (bytes < 500) {
                                        str += AnsiString::StringOfChar(' ',END_SPACE_COUNT);
                                    }
                                }
                                delete[] buf;
                                delete infile;
                            }

                        } //cbLogReader->Checked
                        else {
                            TMemo *buf = new TMemo(this);
                            buf->Visible = false;
                            buf->Parent = this;
                            buf->Lines->LoadFromFile(scrollfilename);
                            str = buf->Text;
                            delete buf;
                        }

                        if (cbUseFrameString->Checked) {
                            if (!getString(str,Memo1->Text,uart_buffer)) {
                                uart_buffer = " ";
                            }
                        }
                        else uart_buffer = str;

                    } //cbPlayFromFile->Checked

                    else if (cbPlayFromWeb->Checked) {
                        page_ready = false;
                        NMHTTP1->Get(editWebAddress->Text);
                        if (page_ready) {
                            if (cbUseFrameString->Checked) {
                                if (!getString(NMHTTP1->Body,Memo1->Text,uart_buffer)) {
                                    uart_buffer = " ";
                                }
                                else uart_buffer += AnsiString::StringOfChar(' ',END_SPACE_COUNT);
                            }
                            else {
                                uart_buffer = NMHTTP1->Body;
                                uart_buffer += AnsiString::StringOfChar(' ',END_SPACE_COUNT);
                            }
                            page_ready = false;
                        }
                        else {
                            uart_buffer = "";
                        }
                    } //cbPlayFromWeb->Checked

                } //mode_scroll_text
                else OperationForm->cancelled=true;
            }
        }
    }

    if (!mode_scroll_text) {
        if (uart_buffer.Length() > 0) {
            OperationForm->setProgressState(send_index*100/uart_buffer.Length());
        }
        if (OperationForm->cancelled) {
            ser->SendByte(TEXT_END);
            ser->CloseSocket();
            OperationForm->Hide();
            enableForm();
            delete[] buff;
            return;
        }
    }

    delete[] buff;
    writeTextTimer->Enabled=true;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::TextReadTextExecute(TObject *Sender)
{
    uart_buffer="";

    if (!connectSerialPort()) return;

    command = AnsiString((char)CMD_START) + (char)CMD_GET_TEXT;
    command_sent=false;
    start_found=false;

    OperationForm->showOperation("Reading text...","Read");

    disableForm();
    readTextTimer->Enabled=true;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::readTextTimerTimer(TObject *Sender)
{
    readTextTimer->Enabled=false;
    unsigned char c;

    //Read byte:
    c = ser->RecvByte(QUICK_TIMEOUT);
    while (ser->LastError == 0) {
        if (!command_sent) {
            if (c > 1) {
                ser->SendBuffer(command.c_str(),2);
                ser->Flush();
                command_sent=true;
            }
        }
        else if (!start_found) {
            if (c == MESSAGE_TEXT_START) start_found=true;
        }
        else if (c == TEXT_END) {
            OperationForm->cancelled=true;
            break;
        }
        else uart_buffer += (char)c;
        OperationForm->setProgressState(uart_buffer.Length()*100/MAX_TEXT_LENGTH);
        c = ser->RecvByte(QUICK_TIMEOUT);
    }

    if (OperationForm->cancelled) {
        ser->CloseSocket();
        Memo1->Text=uart_buffer;
        OperationForm->Hide();
        enableForm();
        return;
    }

    readTextTimer->Enabled=true;
}

//---------------------------------------------------------------------------


void __fastcall TForm1::FontReadFontExecute(TObject *Sender)
{
    if (!connectSerialPort()) return;

    command = AnsiString((char)CMD_START) + (char)CMD_GET_FONT;
    command_sent=false;
    start_found=false;
    col_index=0;
    font_index=1;

    OperationForm->showOperation("Reading font...","Read");

    disableForm();
    readFontTimer->Enabled=true;
}
//---------------------------------------------------------------------------


void __fastcall TForm1::readFontTimerTimer(TObject *Sender)
{
    readFontTimer->Enabled=false;
    unsigned char c;

    //Read byte:
    c = ser->RecvByte(QUICK_TIMEOUT);
    while (ser->LastError == 0) {
        if (!command_sent) {
            if (c > 1) {
                ser->SendBuffer(command.c_str(),2);
                ser->Flush();
                command_sent=true;
            }
        }
        else if (!start_found) {
            if (c == MESSAGE_FONT_START) start_found=true;
        }
        else if (font_index == FONT_MAX_COUNT) {
            OperationForm->cancelled=true;
            break;
        }
        else {
            read_char[col_index]=c;
            if (col_index == 4) {
                bool font[5][7];
                int width=0;
                int xmask=1;
                for(int x=0; x<5; x++) {
                    int ymask=2;
                    for(int y=0; y<7; y++) {
                        if (read_char[x] & ymask) font[x][y]=true;
                        else font[x][y]=false;
                        ymask<<=1;
                    }
                    if (read_char[x] & 1) width |= xmask;
                    xmask<<=1;
                }

                if (font_index < CHARACTERS) {
                    Fonts->setFont5x7(font_index,font);
                    Fonts->charWidth[font_index]=width;
                }
                
                OperationForm->setProgressState((font_index*100)/FONT_MAX_COUNT);
                col_index=0;
                font_index++;
            }
            else col_index++;
        }

        c = ser->RecvByte(QUICK_TIMEOUT);
    }

    if (OperationForm->cancelled) {
        ser->CloseSocket();
        OperationForm->Hide();
        enableForm();
        Editor->EditCharCodeChange(this);   //Causes editor to refresh font
        return;
    }

    readFontTimer->Enabled=true;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FontWriteFontExecute(TObject *Sender)
{
    if (!connectSerialPort()) return;

    command = AnsiString((char)CMD_START) + (char)MESSAGE_FONT_START;
    command_sent=false;

    font_index=1;

    OperationForm->showOperation("Writing font...","Write");

    disableForm();
    writeFontTimer->Enabled=true;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::writeFontTimerTimer(TObject *Sender)
{
    writeFontTimer->Enabled=false;

    int read_count = ser->WaitingData();
    char *buff=new char[read_count+1];

    ser->RecvBuffer(buff,read_count);

    if ((read_count > 0) && (buff[read_count-1] >= 5)) {
        if (!command_sent) {
            ser->SendBuffer(command.c_str(),2);
            ser->Flush();
            command_sent=true;
        }
        else if (font_index == FONT_MAX_COUNT) {
            OperationForm->cancelled=true;
        }
        else {
            bool font[5][7];
            Fonts->getFont5x7(font_index,font);
            int xmask=1;
            for(int x=0; x<5; x++) {
                int ymask=2;
                read_char[x]=0;
                for(int y=0; y<7; y++) {
                    if (font[x][y]) read_char[x] |= ymask;
                    ymask<<=1;
                }
                if (font_index < CHARACTERS && Fonts->charWidth[font_index] & xmask) read_char[x] |= 1;
                xmask<<=1;
            }
            ser->SendBuffer(read_char,5);
            font_index++;
            OperationForm->setProgressState((font_index*100)/FONT_MAX_COUNT);
        }
    }
    if (OperationForm->cancelled) {
        ser->CloseSocket();
        OperationForm->Hide();
        enableForm();
        delete[] buff;
        return;
    }

    delete[] buff;
    writeFontTimer->Enabled=true;
}
//---------------------------------------------------------------------------




