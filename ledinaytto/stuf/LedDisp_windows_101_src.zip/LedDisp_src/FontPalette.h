//---------------------------------------------------------------------------

#ifndef FontPaletteH
#define FontPaletteH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>

#define CHARACTERS          255
#define FIRST_VISIBLE_CHAR  1

class TFontImage : public TImage {
    int index;
    void __fastcall ImageMouseDown(System::TObject* Sender,
                                   TMouseButton Button,
                                   Classes::TShiftState Shift,
                                   int X, int Y);
public:
    __fastcall TFontImage(TComponent *Owner, int _index);
    void __fastcall (__closure *OnFontLeftClick)(int _index);
    void __fastcall (__closure *OnFontRightClick)(int _index);
};


//---------------------------------------------------------------------------
class TFonts : public TForm
{
__published:	// IDE-managed Components
    void __fastcall FormPaint(TObject *Sender);
    void __fastcall FormKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
private:	// User declarations
    void __fastcall drawCursor(TColor color);
    void __fastcall FontImageLeftClick(int index);
    void __fastcall FontImageRightClick(int index);
public:		// User declarations
    __fastcall TFonts(TComponent* Owner);

    TFontImage *fontImages[CHARACTERS];
    int charWidth[CHARACTERS];
    TColor fgColor;
    TColor bgColor;
    TColor cursorColor;
    int cursor_index;
    bool cursor_visible;
    bool Modified;

    void __fastcall getFont5x7(int index, bool dest[5][7]);
    void __fastcall setFont5x7(int index, const bool src[5][7]);
    void __fastcall clearAll(void);
    void __fastcall showCursor();
    void __fastcall hideCursor();
    void __fastcall setCursor(int index);
    bool __fastcall SaveToFile(const AnsiString &filename);
    bool __fastcall LoadFromFile(const AnsiString &filename);
};
//---------------------------------------------------------------------------
extern PACKAGE TFonts *Fonts;
//---------------------------------------------------------------------------
#endif
