
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/signal.h>

typedef unsigned char byte;
typedef signed char sbyte;

#define DATAPORT  PORTD
#define DATA      PIND2		//Siirtorekisterin data
#define SHCLK     PIND4		//Siirtorekisterin shift-clock
#define LCLK      PIND5		//Siirtorekisterin latch-clock
#define OE        PIND3		//Siirtorekisterin output-enable (ei k�yt�ss�)

#define EE_DATAPORT	PORTB
#define EE_INPORT		PINB
#define EE_DATADR		DDRB
#define EE_CLKPORT	PORTD
#define EE_DATA		PINB7		//EEPROM data
#define EE_CLK			PIND6		//EEPROM clock

//Rivien ohjaus (rivi ykk�sell� aktiivinen):
#define ROWPORT   PORTB
#define ROW0      PINB0
#define ROW1      PINB1
#define ROW2      PINB2
#define ROW3      PINB3
#define ROW4      PINB4
#define ROW5      PINB5
#define ROW6      PINB6


#define DISP_WIDTH					50				//N�yt�n leveys
#define MAX_FONT_WIDTH				6				//Fontin maksimileveys
#define UART_BUFFER_SIZE    		20				//Sarjapuskurin koko tavuina

#define DISP_MEM_SIZE      		DISP_WIDTH+MAX_FONT_WIDTH

//N�it� viiveit� voi muuttaa tarpeen mukaan
#define DISP_SCROLL_DELAY  		4		//N�ytt�� siirret��n (65536*DISP_SCROLL_DELAY)/F_CPU sekunnin v�lein
#define RECOVER_DELAY				10		//Viive, joka pidet��n edellisen rivin sammuttamisen ja seuraavan sytytt�misen v�lill�

#define EE_FONTS_START_BLOCK		3		//Mist� EEPROMin 256-tavuisesta lohkosta alkaa fonttidata.
													//Tekstin maksimimerkkim��r� on EE_FONTS_START_BLOCK * 256.
#define EE_TOTAL_BLOCKS				8
#define EE_FONT_WIDTH				5		//Montako tavua pitk� on yhden merkin fonttidata 
													// (montako pikseli� leve� fontin n�kyv� osa voi olla)

#define FONT_MAX_COUNT      (EE_TOTAL_BLOCKS - EE_FONTS_START_BLOCK)*256/EE_FONT_WIDTH

#define F_CPU            10000000L     /* 10Mhz */
#define UART_BAUD_RATE   9600L      /* 9600 baud */

#define UART_BAUD_SELECT (F_CPU/(UART_BAUD_RATE*16)-1)


//Tietoliikennekomennot:

#define CMD_START           	0xFF		//Kaikki tietokoneeelta tulevat komennot alkavat t�ll�.

// Merkin CMD_START j�lkeen tulee joku seuraavista:
//----------------------------------------------------------------------------------------------------
#define CMD_GET_FONT        	0xFE		//K�sket��n n�ytt�� l�hett�m��n fontit EEPROMilta
#define CMD_GET_TEXT        	0xFD		//K�sket��n n�ytt�� l�hett�m��n teksti EEPROMilta

#define CMD_MODE_TEXT_AUTO		0xEF		//Asetetaan automaattinen tekstimoodin valinta
#define CMD_MODE_TEXT_UART		0xEE		//Pakotetaan teksti luettavaksi ainoastaan sarjaportilta
#define CMD_MODE_DIRECT_DRAW	0xED		//Sarjaportilta tuleva data tulkitaan suoraan grafiikaksi
#define CMD_MODE_SHIFT_DRAW	0xEC		//Sama kuin edell�, mutta n�ytt�� siirret��n vain, kun sarjaportilta tulee merkki.
#define CMD_SCR_OFF				0xEB		//K��nt�� n�yt�n piirron pois p��lt�
#define CMD_SCR_ON				0xEA		//K��nt�� n�yt�n piirron takaisin p��lle

#define MESSAGE_FONT_START		0xDD		//T�m� komento aloittaa fonttidatan EEPROMille kirjoitettavaksi
#define MESSAGE_TEXT_START		0x00		//T�m� komento aloittaa tekstidatan EEPROMille kirjoitettavaksi
//----------------------------------------------------------------------------------------------------
#define TEXT_END            	0x00		//T�m� merkki lopettaa tekstidatan

#define CHANGE_MODE_DELAY 10				//Montako t�ytt� fontin leveytt� piirret��n tyhj��, kun automaattisessa
													//tekstimoodissa vaihdetaan tekstin l�hdett� EEPROM <-> UART

//Toimintamoodit, joissa n�ytt� voi olla (arvoa pidet��n muuttujassa control_mode):
#define MODE_TEXT_AUTO		0				//Automaattinen tekstimoodin valinta
#define MODE_TEXT_UART		1				//Teksti luetaan ainoastaan sarjaportilta
#define MODE_WRITE_TEXT		2				//Tekstin kirjoitus EEPROMille
#define MODE_WRITE_FONT		3				//Fontin kirjoitus EEPROMille
#define MODE_SEND_TEXT		4				//Tekstin l�hetys tietokoneelle
#define MODE_SEND_FONT		5				//Fontin l�hetys tietokoneelle
#define MODE_DIRECT_DRAW	6				//Grafiikkamoodi (sarjaportilta tulevat tavut tulkitaan kuin yhden
													// pikselin levyiset fontit ja piirret��n suoraan vieriv�lle ruudulle)
#define MODE_SHIFT_DRAW		7				//Grafiikkamoodi. Kuten edell�, mutta ruutua siirret��n vain kun sarja-
													//portilta luetaan uusi merkki.

byte display[DISP_MEM_SIZE];
byte uart_buffer[UART_BUFFER_SIZE];
byte font[MAX_FONT_WIDTH];

volatile byte disp_start = 0;
volatile byte disp_end = DISP_WIDTH-1;
volatile sbyte disp_shift_count=0;
//volatile byte new_char_to_scr=0;

byte uart_buffer_start = 0;
volatile byte uart_buffer_end = 0;
volatile byte bytes_in_buffer = 0;

byte txt_block=0;
byte txt_address=0;

byte control_mode = MODE_TEXT_AUTO;
byte prev_mode = MODE_TEXT_AUTO;
byte change_mode_count = CHANGE_MODE_DELAY;
byte font_count=0;
int byte_count=0;
byte timeout=0;

void uart_send_byte(byte b);
byte ee_read_byte(byte block, byte address);
byte ee_write_byte(byte b, byte block, byte address);

/* signal handler for timer1 compare match interrupt */
SIGNAL(SIG_OUTPUT_COMPARE1A) {
	if (control_mode == MODE_WRITE_TEXT || control_mode == MODE_WRITE_FONT) { 
		uart_send_byte(UART_BUFFER_SIZE-bytes_in_buffer);
	}
	//if (new_char_to_scr) return;
	if (disp_shift_count < 0) return;
   //Scroll display
   disp_start++;
   if (disp_start >= DISP_MEM_SIZE) disp_start=0;
   disp_end++;
   if (disp_end >= DISP_MEM_SIZE) disp_end=0;
	//if (disp_shift_count == 0) new_char_to_scr = 1;	//Put new character to display memory (after index disp_end)
	disp_shift_count--;
}


/* signal handler for receive complete interrupt */
SIGNAL(SIG_UART_RECV) {
	if (bytes_in_buffer == UART_BUFFER_SIZE) {
		byte crap = UDR;
	}
	else {
		uart_buffer[uart_buffer_end] = UDR;
		uart_buffer_end++;
		if (uart_buffer_end == UART_BUFFER_SIZE) uart_buffer_end=0;
		bytes_in_buffer++;
	}
}


void uart_send_byte(byte b) {
	while ((USR & _BV(UDRE)) == 0) ;	//Odotetaan, ett� edellinen l�hetys valmistuu.
	UDR = b;
}


byte get_byte_from_buffer(void) {
	if (bytes_in_buffer == 0) return 0;
	byte b = uart_buffer[uart_buffer_start++];
	if (uart_buffer_start == UART_BUFFER_SIZE) uart_buffer_start=0;
	bytes_in_buffer--;
	return b;
}


void set_mode(void) {
	byte cmd=get_byte_from_buffer();		//Otetaan CMD_START pois puskurista
	while (bytes_in_buffer == 0);		//Odotetaan komentoa
	cmd=get_byte_from_buffer();
	switch(cmd) {
		case CMD_GET_TEXT:	
			prev_mode = control_mode;
			control_mode = MODE_SEND_TEXT;
			uart_send_byte(MESSAGE_TEXT_START);
			txt_address=0;
			txt_block=0;
			break;
		case MESSAGE_TEXT_START:
			prev_mode = control_mode;
			control_mode = MODE_WRITE_TEXT;
			txt_address=0;
			txt_block=0;
			break;
		case CMD_GET_FONT:
			prev_mode = control_mode;
			control_mode = MODE_SEND_FONT;
			uart_send_byte(MESSAGE_FONT_START);
			txt_address=EE_FONT_WIDTH;			//J�tet��n nollas merkki v�list�
			txt_block=EE_FONTS_START_BLOCK;
			font_count=(byte)(FONT_MAX_COUNT-1);
			break;
		case MESSAGE_FONT_START:
			prev_mode = control_mode;
			control_mode = MODE_WRITE_FONT;
			txt_address=EE_FONT_WIDTH;			
			txt_block=EE_FONTS_START_BLOCK;
			byte_count=(FONT_MAX_COUNT-1)*EE_FONT_WIDTH;
			timeout=0;
			break;
	}
}
	

void row_delay(void) {
   byte a;
   for(a=0; a<RECOVER_DELAY; a++) asm("nop");
}


void get_font(byte c) {
	byte b;
	byte font_address=0, font_block=EE_FONTS_START_BLOCK;
	int address=c*EE_FONT_WIDTH;
	font_block+=address/256;
	font_address=address%256;
	for(b=0; b<EE_FONT_WIDTH; b++) {
		font[b]=ee_read_byte(font_block, font_address);
		if (++font_address==0) font_block++;
	}
}	


void clear_font(void) {
	byte a;
	byte mask=1;
	for(a=0; a<MAX_FONT_WIDTH; a++) {
		if (MAX_FONT_WIDTH & mask) font[a] = 1;
		else font[a] = 0;
		mask<<=1;
	}
}


//Piirt�� fontin fonttipuskurista n�ytt�muistiin. 
//Funktio palauttaa piirrettyjen sarakkeiden m��r�n.
byte font_to_scr(void) {
	byte c, width=0;
	byte mask=1;
	for(c=0;c<EE_FONT_WIDTH; c++) {
		if (font[c] & 1) width |= mask;
		mask<<=1;
	}
	if (width > MAX_FONT_WIDTH) width = MAX_FONT_WIDTH;
	byte char_col=disp_end+1;
	for(c=0;c<width;c++) {
		if (char_col >= DISP_MEM_SIZE) char_col=0;
		display[char_col]=font[c];
		char_col++;
	}
	return width;
}


void char_to_scr(void) {
	clear_font();
	if (control_mode == MODE_TEXT_AUTO || control_mode == MODE_TEXT_UART) {
		
		if (bytes_in_buffer == 0) {
			uart_send_byte(UART_BUFFER_SIZE);
			if (control_mode == MODE_TEXT_AUTO) {
				change_mode_count++;
				if (change_mode_count > CHANGE_MODE_DELAY) {
					change_mode_count = 2*CHANGE_MODE_DELAY;
					byte c = ee_read_byte(txt_block,txt_address);
					if (c == TEXT_END) {
						txt_address=0;
						txt_block=0;
					}
					else {
						get_font(c);
						if (++txt_address == 0) txt_block++;
					}
				}
			}
			else change_mode_count=0;
		}
	
		else {
			uart_send_byte(UART_BUFFER_SIZE-bytes_in_buffer);
			if (uart_buffer[uart_buffer_start] == CMD_START) set_mode();
			else if (change_mode_count > CHANGE_MODE_DELAY) change_mode_count--;
			else {
				byte c = get_byte_from_buffer();
				get_font(c);
				change_mode_count=0;
				txt_address=0;
				txt_block=0;
			}
		}
		
	}
	
	disp_shift_count += font_to_scr();
	//byte width = font_to_scr();
	//if (width > 0) {
	//	disp_shift_count+=width;
	//	new_char_to_scr = 0;
	//}
}



void draw_screen(void) {
   byte rowmask,i;
	//Bittimaski, jolla muistista otetaan oikea bitti. Aloitetaan toisen piirrett�v�n rivin kohdalta.
	//V�hiten merkitsev�� bitti� ei siirret� muistista n�yt�lle, koska n�yt�ss� on vain 7 rivi�
   byte memmask=4;	
	
   for(rowmask=1; rowmask<0x80; rowmask<<=1) {		//Piirret��n rivit 0-6
		//Edellisen rivin data siirtorekisterien ulostuloihin
		DATAPORT |= _BV(LCLK);		//Aseta nasta LCLK (Latch clock)
		DATAPORT &= ~_BV(LCLK);	//Nollaa nasta LCLK
		//Edellinen rivi palaa samalla kun siirret��n dataa nykyiselle riville
		ROWPORT |= rowmask;			//Sytyt� maskin osoittama rivi (eli transistorin ohjausnasta yl�s).
		if (memmask == 0) memmask=2;	//Kun muistimaski menee viimeisen rivin ohi, valitaan ensimm�inen rivi
      cli();	//Rivi halutaan tallentaa rauhassa; ei keskeytyksi�. Nyt rivi ei muutu kesken kaiken.
		i=disp_start;	//Aloitetaan ensimm�isest� sarakkeesta.
      do {
         if (i >= DISP_MEM_SIZE) i=0;
			if (display[i] & memmask) DATAPORT |= _BV(DATA);		//sbi(DATAPORT,DATA);
			DATAPORT |= _BV(SHCLK);		   								//sbi(DATAPORT,SHCLK);
			DATAPORT &= ~_BV(SHCLK);										//cbi(DATAPORT,SHCLK);
			DATAPORT &= ~_BV(DATA);										//cbi(DATAPORT,DATA);
      } while(i++ != disp_end);		
      sei();	//Nyt saa taas keskeytt��.
      memmask<<=1;
		ROWPORT &= ~rowmask;		//Sammutetaan edellinen rivi. Siirtorekisteriss� on nyt seuraavan rivin data
		row_delay();				//Pidet��n tauko, jotta transistori ehtii kunnolla lakata johtamasta.
   }
	//Eli silmukan p��tteeksi siirtorekistereihin j�� seuraavaa 
	//p�ivityst� varten ensimm�isen rivin sis�lt�.
}



/*********************************************/
/*   P��ohjelma: hoitaa n�yt�n p�ivityksen   */
/*********************************************/

int main(void) {
	byte a;
   for(a=0; a<DISP_MEM_SIZE; a++) {
      display[a]=0;
   }

   PORTB=0; 
   PORTD=0; 
   DDRB=0xFF;       	/* PortB output */
   DDRD=0xFF; 			/* PortD output */

	TIMSK = _BV(OCIE1A); 			/* Enable interrupt on compare match */		
	TCCR1B = (4 | _BV(CTC1));    /* count with cpu clock/256, clear timer on compare match */
	OCR1AH = DISP_SCROLL_DELAY; 
	OCR1AL = 0; 
	/* enable RxD/TxD and int */
   UCR = _BV(RXCIE) | _BV(RXEN) | _BV(TXEN);       
   /* set baud rate */
   UBRR = UART_BAUD_SELECT;        

   sei();                   /* enable interrupts */

   a=0;
   while (1) {
		if (control_mode == MODE_SEND_TEXT) {
			if ((USR & _BV(UDRE)) != 0) {
				byte c = TEXT_END;
				if (txt_block < EE_FONTS_START_BLOCK) c = ee_read_byte(txt_block,txt_address);
				UDR = c;
				if (c == TEXT_END) {
					txt_address=0;
					txt_block=0;
					control_mode = prev_mode;
					if (control_mode == MODE_TEXT_UART) change_mode_count=2*CHANGE_MODE_DELAY;
					else change_mode_count=0;
				}
				else if (++txt_address == 0) txt_block++;
			}
		}
		else if (control_mode == MODE_WRITE_TEXT) {
			while (bytes_in_buffer > 0) {
				byte c = get_byte_from_buffer();
				if ( txt_block == EE_FONTS_START_BLOCK || (ee_write_byte(c,txt_block,txt_address) != 0) || (c == TEXT_END) ) {
					txt_address=0;
					txt_block=0;
					control_mode = prev_mode;
					if (control_mode == MODE_TEXT_UART) change_mode_count=2*CHANGE_MODE_DELAY;
					else change_mode_count=0;
				}
				else if (++txt_address == 0) txt_block++;
			}
		}
		else if (control_mode == MODE_SEND_FONT) {
			byte a;
			for (a=0; a < EE_FONT_WIDTH; a++) {
				byte c = ee_read_byte(txt_block,txt_address);
				uart_send_byte(c);
				if (++txt_address == 0) txt_block++;
			}
			if (--font_count == 0) {
				txt_address=0;
				txt_block=0;
				control_mode = prev_mode;
				if (control_mode == MODE_TEXT_UART) change_mode_count=2*CHANGE_MODE_DELAY;
				else change_mode_count=0;
			}
		}
		else if (control_mode == MODE_WRITE_FONT) {
			while (bytes_in_buffer > 0) {
				byte c = get_byte_from_buffer();
				if ((ee_write_byte(c,txt_block,txt_address) != 0) || --byte_count == 0) {
					timeout=0xFF;	//End
				}
				else {
					if (++txt_address == 0) txt_block++;
					timeout=0;
				}
			}
			timeout++;
			if (timeout == 0) {
				txt_address=0;
				txt_block=0;
				control_mode = prev_mode;
				if (control_mode == MODE_TEXT_UART) change_mode_count=2*CHANGE_MODE_DELAY;
				else change_mode_count=0;
			}
		}
		
      draw_screen();
		if (disp_shift_count < 0) char_to_scr();
   }
}



//----------------------------------------------------------------------

/**********************************************************/
/*             I2C - rutiineja (EEPROMia varten)          */
/*                                                        */
/* Kiitokset Mikko Kursulalle, jonka ledin�yt�n koodista  */
/* I2C-lukurutiinit on osittain siirretty                 */
/**********************************************************/

//Rutiinien sis�iset muuttujat, jotka pit�v�t kirjaa nykyisest�
//muistilohkosta ja osoitteesta lohkon sis�ll�. N�in p��rutiinin
//ei tarvitse tiet��, milloin pit�� kirjoittaa uusi osoite EEPROMille
byte ee_block=255, ee_address=255;

void delay_10ms(void) {
	byte a; byte b;
	for (a=0; a < ((F_CPU/102400L)+1); a++) { 		//Yksi kierros vie noin 1024 kelloa
		for (b=0; b<255; b++);
	}
}

//Tauko, joka pidet��n v�h�n joka v�liss�.
void ee_wait(void) {
	asm("nop\nnop\nnop\nnop");
}


//Asettaa AVR:st� EEPROMin datapinnin lukutilaan
void ee_set_data_input(void) {
	cbi(EE_DATADR, EE_DATA);		//Datapinni lukutilaan
	sbi(EE_DATAPORT, EE_DATA);		//Asetetaan sis�inen pull-uppi, jotta voidaan lukea (24C16 vaatii).
}


//Asettaa AVR:st� EEPROMin datapinnin kirjoitustilaan
void ee_set_data_output(void) {
	cbi(EE_DATAPORT, EE_DATA);		//Nollataan datapinni, koska yll� olevassa rutiinissa
	                              // se asetettiin sis�isen pull-upin takia.
	sbi(EE_DATADR, EE_DATA); 		//Datapinni kirjoitustilaan
}



/*********************************/
/*   Lukurutiinin aliohjelmat:   */
/*********************************/

//L�hett�� EEPROMille ykk�sen
void ee_bit1(void) {
	sbi(EE_DATAPORT, EE_DATA);
	sbi(EE_CLKPORT, EE_CLK);
	ee_wait();
	cbi(EE_CLKPORT, EE_CLK);
	ee_wait();
	cbi(EE_DATAPORT, EE_DATA);
	ee_wait();
}

//L�hett�� EEPROMille nollan
void ee_bit0(void) {
	sbi(EE_CLKPORT, EE_CLK);
	ee_wait();
	cbi(EE_CLKPORT, EE_CLK);
	ee_wait();
}

//L�hett�� EEPROMille aloitusmerkin
void ee_start(void) {
	sbi(EE_DATAPORT, EE_DATA);
	sbi(EE_CLKPORT, EE_CLK);
	ee_wait();
	cbi(EE_DATAPORT, EE_DATA);
	ee_wait();
	cbi(EE_CLKPORT, EE_CLK);
	ee_wait();
	
	ee_bit1();
	ee_bit0();
	ee_bit1();
	ee_bit0();
}

//L�hett�� EEPROMille lopetusmerkin.
//Kellonasta ja datanasta j�tet��n yl�s seuraavaa aloitusmerkki� varten, joten
//mik��n muu rutiini EI SAA muuttaa datanastaa siin� v�liss�.
//(Kellonastan ollessa ylh��ll� datanastan muutokset tulkitaan aloitus/lopetusmerkeiksi)
void ee_stop(void) {
	sbi(EE_CLKPORT, EE_CLK);
	sbi(EE_DATAPORT, EE_DATA);
}

//L�hetet��n EEPROMIlle muistilohkon numero
void ee_select_block(void) {
	if (ee_block & 4) ee_bit1();
	else ee_bit0();
	if (ee_block & 2) ee_bit1();
	else ee_bit0();
	if (ee_block & 1) ee_bit1();
	else ee_bit0();
}

//Kirjoitetaan uusi osoite EEPROMille
void ee_write_address(byte block, byte address) {
	ee_block=block;
	ee_address=address;
	
	ee_start();
	ee_select_block();
	
	ee_bit0();	//write
	ee_bit0();	//ACK

	byte mask;
	for (mask=0x80; mask>0; mask>>=1) {
		if (address & mask) ee_bit1();
		else ee_bit0();
	}
	
	ee_bit0();	//ACK
}

//Lukee EEPROMilta tavun nykyisest� osoitteesta.
//Lukemisen j�lkeen EEPROM lis�� osoitetta automaattisesti yhdell�
byte ee_read_next_byte(void) {
	ee_start();
	ee_select_block();
	
	ee_bit1();	//read
	ee_bit0();	//ACK
	
	ee_set_data_input();
	
	byte b=0,mask;
	for (mask=0x80; mask>0; mask>>=1) {
		sbi(EE_CLKPORT, EE_CLK);
		ee_wait();
		if (EE_INPORT&(1<<EE_DATA)) b|=mask;
		cbi(EE_CLKPORT, EE_CLK);
		ee_wait();
	}
	
	ee_set_data_output();
	ee_stop();
	
	ee_address++;		//Lis�t��n (8-bittist�) osoitetta yhdell� my�s ohjelmassa, 
							//niin tiedet��n EEPROMin osoite (joka my�s kiert�� 255->0)
	return b;
}



/***********************************/
/*  Kirjoitusrutiinin aliohjelma:  */
/***********************************/

byte ee_byte_out(byte b) {
	byte mask;
	for (mask=0x80; mask>0; mask>>=1) {
		cbi(EE_CLKPORT, EE_CLK);
		ee_wait();
		if (b & mask) sbi(EE_DATAPORT, EE_DATA);
		else cbi(EE_DATAPORT, EE_DATA);
		sbi(EE_CLKPORT, EE_CLK);
		ee_wait();
	}
	cbi(EE_CLKPORT, EE_CLK);
	sbi(EE_DATAPORT, EE_DATA);
	ee_wait();
	ee_wait();
	sbi(EE_CLKPORT, EE_CLK);
	ee_set_data_input();
	byte timeout;
	for(timeout=255; timeout>0; timeout--) {		//Wait for ACK
		if ((EE_INPORT & _BV(EE_DATA)) == 0) {
			ee_set_data_output();
			return 0;
		}
		ee_wait();
		ee_wait();
		ee_wait();
		ee_wait();
		ee_wait();
	}
	
	ee_set_data_output();
	return 1;	//Timeout
}



/*************************************************
  N�it� rutiineja p��ohjelma kutsuu:
*************************************************/

//Luetaan tavu EEPROMilta annetusta muistilohkosta ja osoitteesta
byte ee_read_byte(byte block, byte address) {
	if (block!=ee_block || address!=ee_address) ee_write_address(block,address);
	return ee_read_next_byte();
}

//Kirjoitetaan tavu EEPROMille annettuun muistilohkoon ja osoitteeseen. Palauttaa 0, jos onnistui.
byte ee_write_byte(byte b, byte block, byte address) {
	ee_block=block;
	ee_address=address;
	sbi(EE_DATAPORT, EE_DATA);
	sbi(EE_CLKPORT, EE_CLK);
	ee_wait();
	cbi(EE_DATAPORT, EE_DATA);
	ee_wait();

	byte control=0xA0;	//10100000b
	control |= (block<<1);
	if (ee_byte_out(control)) return 1;
	if (ee_byte_out(address)) return 1;
	if (ee_byte_out(b)) return 1;
	
	cbi(EE_CLKPORT, EE_CLK);
	ee_wait();
	cbi(EE_DATAPORT, EE_DATA);
	ee_wait();
	sbi(EE_CLKPORT, EE_CLK);
	ee_wait();
	sbi(EE_DATAPORT, EE_DATA);
	
	delay_10ms();	//Odotetaan, ett� merkki ehdit��n varmasti kirjoittaa
	
	return 0;
}


